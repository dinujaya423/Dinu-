<div class = "repo" align = "center">
 
<a href = "#">
<img src = "https://i.ibb.co/C5Rzcsmw/20250331-085303.jpg"  width="640" height="309">
</img>
 
---
<a href="https://git.io/typing-svg">
    <img src="https://readme-typing-svg.herokuapp.com?color=FF1043&lines=Welcome+to+my+Repository!;QUEEN+ANJU+XPRO;Thanks+for+visiting!"/>
</a>

---

### 🏆 GitHub Achievements
<p align="center">
  <img src="https://github-profile-trophy.vercel.app/?username=dinujaya423&theme=darkhub&no-frame=true&margin-w=4"/>
</p>

---

<p align="center">
<img src="https://github.com/Platane/snk/raw/output/github-contribution-grid-snake.svg" alt="nz" width="700"/>
</p>

---

<p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-DINU_MD-red.svg?style=for-the-badge&logo=github"></a>
<a href="#"><img title="LOGO DESIGNER" src="https://img.shields.io/badge/LOGO_DESIGNER-DINU_MD-red.svg?style=for-the-badge&logo=github"></a>
;

### Please Read !
Queen Anju is a whatsapp bot created by Gaming rash ( Janith Rashmika ) using baileys web api. Do not use this bot in a way that will cause trouble to others. 
We are not responsible for any problems caused by your use of this!
And Subscribe GAMING RASH and give one star for queen anju.
</br>
#### Give One star For Dinu-Md and [Follow Me](https://github.com/dinujaya423/SR-TECH_DINU) 

## How create Dinu-Md.

**. Deploy steps.*
 - 1._Fork Dinu-Md repository._
    <br>
    <a href="https://github.com/dinujaya423/SR-TECH-DINU"><img title="DINU_MD" src="https://img.shields.io/badge/FORK DINU_MD-h?color=black&style=for-the-badge&logo=stackshare"></a>
 - 2._Link with yoour whatsappp using pair code._
   **Pair with WhatsApp*

   @SITE 1
   <p align="center">
       <a href="https://Pair-Dinu-bot.onrender.com/">
         <img src="https://i.ibb.co/C5Rzcsmw/20250331-085303.jpg"90" />
       </a>
   </p>
   
  
   </p>
 - _Open config.js on your forked repository. and put `SESSION_ID` and change other settings you need._
 - _Deploy using your host._
   </br>

  1..DEPLOY ON RENDER

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/Mrrashmika/QUEEN-ANJU_XPRO.git)


   2..DEPLOY ON GITHUB

***<p align="center"> • [`Tap here for Github deploy tutorial`](https://youtu.be/NHxe-ynZmGI) </p>***

   3..DEPLOY ON KOYEB

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?name=queen-anju-md&type=git&repository=Mrrashmika%2FQueen_Anju-MD&branch=V-2.00&builder=dockerfile&env%5BMONGODB%5D=your+mongodb+uri&env%5BSESSION_ID%5D=your+session+id&ports=8000%3Bhttp%3B%2F)


